<?php
     include_once "conexao.php";

     $email = $_GET["email"];  
     $password = $_GET["senha"];
     $nome = $_GET["nome"];

     /* echo "Nome: $nome <br>"; 
     echo "Email: $email<br>"; 
     echo "Senha: $password<br>"; */

     //verificar se este email já está cadastrado
     $sql2 = $dbcon->query("SELECT * FROM tblogin WHERE email ='$email'");

     if(mysqli_num_rows($sql2)>0) {
        echo "email_erro";

    }else{
        //inserir no banco ==> INSERT 
        $sql3 = $dbcon->query("INSERT INTO tblogin(nome,email,senha) VALUES('$nome','$email','$password')");
        if ($sql3){
        echo "registro_ok";
        }else{
        echo "registro_erro";
        }

    } 

   
    

 


?>