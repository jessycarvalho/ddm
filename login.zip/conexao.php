<?php
   $host = "localhost";
   $user = "root";
   $password = "";
   $bd = "bdlogin";

   $dbcon = new MySQLi("$host","$user","$password","$bd");

   if($dbcon->connect_error){
       echo "conexao_erro";
   }/* else{
       echo "conexao_ok";
   }*/





?>